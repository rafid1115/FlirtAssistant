package com.flirtassistant

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val textReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "com.flirtassistant.NEW_TEXT" -> {
                    val text = intent.getStringExtra("text") ?: return
                    processNewText(text)
                }
                "com.flirtassistant.HIDE_OVERLAY" -> {
                    hideBubble()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val filter = IntentFilter().apply {
            addAction("com.flirtassistant.NEW_TEXT")
            addAction("com.flirtassistant.HIDE_OVERLAY")
        }
        registerReceiver(textReceiver, filter)

        createNotificationChannel()
        startForeground(1, buildNotification())
        showBubble()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "flirt_service",
                "FlirtAssistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "FlirtAssistant פועל ברקע"
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, "flirt_service")
            .setContentTitle("💘 FlirtAssistant פעיל")
            .setContentText("מוכן להציע תגובות פלרטטניות")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(intent)
            .build()
    }

    private fun showBubble() {
        if (bubbleView != null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) return

        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.overlay_bubble, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = 20
            y = 200
        }

        // Make bubble draggable
        var lastX = 0; var lastY = 0
        var dragStartX = 0f; var dragStartY = 0f
        bubbleView?.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = event.rawX
                    dragStartY = event.rawY
                    lastX = params.x
                    lastY = params.y
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = lastX - (event.rawX - dragStartX).toInt()
                    params.y = lastY - (event.rawY - dragStartY).toInt()
                    windowManager.updateViewLayout(bubbleView, params)
                    true
                }
                else -> false
            }
        }

        bubbleView?.setOnClickListener {
            togglePanel()
        }

        windowManager.addView(bubbleView, params)
    }

    private fun hideBubble() {
        bubbleView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {}
            bubbleView = null
        }
        hidePanel()
    }

    private var currentSuggestions = listOf<String>()
    private var isLoading = false

    private fun processNewText(text: String) {
        val prefs = getSharedPreferences("flirt_prefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""
        if (apiKey.isBlank()) {
            showBubbleError("הגדר API Key בהגדרות")
            return
        }

        val flirtLevel = prefs.getInt("flirt_level", 5)

        isLoading = true
        updateBubbleState()

        serviceScope.launch {
            val result = ClaudeApiClient.getFlirtyResponse(text, apiKey, flirtLevel)
            isLoading = false

            result.onSuccess { suggestions ->
                currentSuggestions = suggestions
                updateBubbleReady()
                // Auto-show panel if it's not visible
                if (panelView == null) showPanel()
                updatePanelSuggestions()
            }.onFailure { error ->
                showBubbleError("שגיאה: ${error.message?.take(50)}")
            }
        }
    }

    private fun updateBubbleState() {
        bubbleView?.findViewById<TextView>(R.id.tvBubbleEmoji)?.text = if (isLoading) "⏳" else "💘"
    }

    private fun updateBubbleReady() {
        bubbleView?.findViewById<TextView>(R.id.tvBubbleEmoji)?.text = "💬"
    }

    private fun showBubbleError(msg: String) {
        bubbleView?.findViewById<TextView>(R.id.tvBubbleEmoji)?.text = "⚠️"
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun togglePanel() {
        if (panelView != null) hidePanel() else showPanel()
    }

    private fun showPanel() {
        if (panelView != null) return

        val inflater = LayoutInflater.from(this)
        panelView = inflater.inflate(R.layout.overlay_panel, null)

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.9).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 50
        }

        panelView?.findViewById<ImageButton>(R.id.btnClose)?.setOnClickListener {
            hidePanel()
        }

        windowManager.addView(panelView, params)
        updatePanelSuggestions()
    }

    private fun updatePanelSuggestions() {
        val panel = panelView ?: return

        if (isLoading) {
            panel.findViewById<LinearLayout>(R.id.llSuggestions).visibility = View.GONE
            panel.findViewById<TextView>(R.id.tvLoading).visibility = View.VISIBLE
            return
        }

        panel.findViewById<TextView>(R.id.tvLoading).visibility = View.GONE
        panel.findViewById<LinearLayout>(R.id.llSuggestions).visibility = View.VISIBLE

        val labels = listOf("😄 שנוני", "💕 רומנטי", "🔥 נועז")
        val buttons = listOf(
            panel.findViewById<Button>(R.id.btn1),
            panel.findViewById<Button>(R.id.btn2),
            panel.findViewById<Button>(R.id.btn3)
        )
        val textViews = listOf(
            panel.findViewById<TextView>(R.id.tv1),
            panel.findViewById<TextView>(R.id.tv2),
            panel.findViewById<TextView>(R.id.tv3)
        )

        currentSuggestions.forEachIndexed { i, suggestion ->
            if (i < textViews.size) {
                textViews[i].text = suggestion
                buttons[i].text = labels.getOrElse(i) { "תגובה ${i+1}" }
                buttons[i].setOnClickListener {
                    copyToClipboard(suggestion)
                    Toast.makeText(this, "✅ הועתק! הדבק בצ'אט", Toast.LENGTH_SHORT).show()
                    hidePanel()
                }
            }
        }
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("flirt", text))
    }

    private fun hidePanel() {
        panelView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {}
            panelView = null
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        hideBubble()
        try { unregisterReceiver(textReceiver) } catch (e: Exception) {}
    }
}
