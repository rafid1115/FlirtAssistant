package com.flirtassistant

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.flirtassistant.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun setupUI() {
        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            }
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnToggle.setOnClickListener {
            val prefs = getSharedPreferences("flirt_prefs", Context.MODE_PRIVATE)
            val enabled = prefs.getBoolean("service_enabled", true)
            prefs.edit().putBoolean("service_enabled", !enabled).apply()
            updateStatus()

            // Notify accessibility service
            sendBroadcast(Intent("com.flirtassistant.TOGGLE_SERVICE"))
        }
    }

    private fun updateStatus() {
        val accessibilityGranted = isAccessibilityEnabled()
        val overlayGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true

        val prefs = getSharedPreferences("flirt_prefs", Context.MODE_PRIVATE)
        val serviceEnabled = prefs.getBoolean("service_enabled", true)

        // Accessibility status
        binding.statusAccessibility.text = if (accessibilityGranted) "✅ פעיל" else "❌ נדרש אישור"
        binding.statusAccessibility.setTextColor(
            ContextCompat.getColor(this, if (accessibilityGranted) R.color.green else R.color.red)
        )

        // Overlay status
        binding.statusOverlay.text = if (overlayGranted) "✅ פעיל" else "❌ נדרש אישור"
        binding.statusOverlay.setTextColor(
            ContextCompat.getColor(this, if (overlayGranted) R.color.green else R.color.red)
        )

        // Main toggle
        val allGranted = accessibilityGranted && overlayGranted
        binding.btnToggle.isEnabled = allGranted
        binding.btnToggle.text = if (serviceEnabled && allGranted) "⏸ השהה את FlirtAssistant" else "▶ הפעל את FlirtAssistant"
        binding.tvMainStatus.text = when {
            !allGranted -> "⚠️ אשר הרשאות כדי להמשיך"
            serviceEnabled -> "💘 FlirtAssistant פעיל!"
            else -> "😴 FlirtAssistant מושהה"
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }
}
