package com.flirtassistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object ClaudeApiClient {

    private const val API_URL = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-haiku-4-5-20251001" // Fast & cheap for real-time use

    suspend fun getFlirtyResponse(
        conversationText: String,
        apiKey: String,
        flirtLevel: Int = 5,
        language: String = "he"
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val flirtDescription = when {
                flirtLevel <= 3 -> "קלה ועדינה, כמו מחמאה אדיבה"
                flirtLevel <= 6 -> "בינונית, חמה וחיובית עם רמז רומנטי"
                else -> "נועזת, ישירה ומלאת ביטחון"
            }

            val langInstruction = if (language == "he") "ענה בעברית" else "Respond in English"

            val systemPrompt = """
                אתה עוזר פלרטוט חכם. תפקידך לנתח שיחות ולהציע תגובות פלרטטניות מתאימות.
                רמת הפלרטוט: $flirtDescription (רמה $flirtLevel מתוך 10).
                $langInstruction.
                
                כללים:
                - הצע בדיוק 3 תגובות שונות, קצרות (עד 2 משפטים כל אחת)
                - כל תגובה תתאים לסגנון שונה: שנונה / רומנטית / נועזת
                - אל תסביר, רק תן את התגובות
                - פורמט JSON בלבד: {"responses": ["תגובה1", "תגובה2", "תגובה3"]}
            """.trimIndent()

            val userMessage = """
                הנה הטקסט מהשיחה:
                ---
                $conversationText
                ---
                הצע 3 תגובות פלרטטניות מתאימות לטקסט הזה.
            """.trimIndent()

            val requestBody = JSONObject().apply {
                put("model", MODEL)
                put("max_tokens", 500)
                put("system", systemPrompt)
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", userMessage)
                    })
                })
            }

            val url = URL(API_URL)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("x-api-key", apiKey)
            connection.setRequestProperty("anthropic-version", "2023-06-01")
            connection.doOutput = true
            connection.connectTimeout = 10000
            connection.readTimeout = 15000

            connection.outputStream.use { os ->
                os.write(requestBody.toString().toByteArray())
            }

            val responseCode = connection.responseCode
            val responseText = if (responseCode == 200) {
                BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
            } else {
                BufferedReader(InputStreamReader(connection.errorStream)).use { it.readText() }
            }

            if (responseCode != 200) {
                return@withContext Result.failure(Exception("API Error $responseCode: $responseText"))
            }

            // Parse response
            val jsonResponse = JSONObject(responseText)
            val content = jsonResponse.getJSONArray("content")
                .getJSONObject(0)
                .getString("text")

            // Extract JSON from Claude's response
            val jsonMatch = Regex("\\{.*\"responses\".*\\}", RegexOption.DOT_MATCHES_ALL)
                .find(content)?.value ?: content

            val suggestions = JSONObject(jsonMatch).getJSONArray("responses")
            val result = mutableListOf<String>()
            for (i in 0 until suggestions.length()) {
                result.add(suggestions.getString(i))
            }

            Result.success(result)

        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
