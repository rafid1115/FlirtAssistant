package com.flirtassistant

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*

class FlirtAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var lastText = ""
    private var lastProcessedText = ""
    private var isEnabled = true
    private var debounceJob: Job? = null

    // Messaging app package names to monitor
    private val messagingApps = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "com.facebook.orca",  // Messenger
        "com.instagram.android",
        "com.twitter.android",
        "com.snapchat.android",
        "com.viber.voip",
        "com.skype.raider",
        "com.discord",
        "com.tinder",
        "com.bumble.app",
        "com.badoo.mobile",
        "com.match.android.matchapp",
        "com.hinge.app",
        "il.co.drush.msngr", // Israeli apps
        "com.sms",
        "com.google.android.apps.messaging"
    )

    private val toggleReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val prefs = getSharedPreferences("flirt_prefs", Context.MODE_PRIVATE)
            isEnabled = prefs.getBoolean("service_enabled", true)
            if (!isEnabled) {
                sendBroadcast(Intent("com.flirtassistant.HIDE_OVERLAY"))
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val prefs = getSharedPreferences("flirt_prefs", Context.MODE_PRIVATE)
        isEnabled = prefs.getBoolean("service_enabled", true)
        registerReceiver(toggleReceiver, IntentFilter("com.flirtassistant.TOGGLE_SERVICE"))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isEnabled || event == null) return

        val packageName = event.packageName?.toString() ?: return

        // Check if it's a messaging app (or monitor ALL apps if setting enabled)
        val prefs = getSharedPreferences("flirt_prefs", Context.MODE_PRIVATE)
        val monitorAll = prefs.getBoolean("monitor_all_apps", false)

        if (!monitorAll && !messagingApps.contains(packageName)) return

        // Extract text from the screen
        val rootNode = rootInActiveWindow ?: return
        val screenText = extractConversationText(rootNode)
        rootNode.recycle()

        if (screenText.isNotBlank() && screenText != lastProcessedText && screenText.length > 10) {
            lastText = screenText
            // Debounce - wait 1.5 seconds of no changes before processing
            debounceJob?.cancel()
            debounceJob = serviceScope.launch {
                delay(1500)
                if (screenText == lastText) {
                    processText(screenText, packageName)
                }
            }
        }
    }

    private fun extractConversationText(node: AccessibilityNodeInfo): String {
        val texts = StringBuilder()
        extractTextsFromNode(node, texts, depth = 0, maxDepth = 8)
        return texts.toString().trim()
    }

    private fun extractTextsFromNode(
        node: AccessibilityNodeInfo,
        builder: StringBuilder,
        depth: Int,
        maxDepth: Int
    ) {
        if (depth > maxDepth) return

        // Get text from this node
        val text = node.text?.toString()?.trim()
        if (!text.isNullOrBlank() && text.length > 2) {
            builder.append(text).append("\n")
        }

        // Recurse into children
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            extractTextsFromNode(child, builder, depth + 1, maxDepth)
            child.recycle()
        }
    }

    private fun processText(text: String, packageName: String) {
        if (text == lastProcessedText) return
        lastProcessedText = text

        // Send to overlay service for AI processing and display
        val intent = Intent("com.flirtassistant.NEW_TEXT").apply {
            putExtra("text", text)
            putExtra("package", packageName)
        }
        sendBroadcast(intent)
    }

    override fun onInterrupt() {
        debounceJob?.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        try { unregisterReceiver(toggleReceiver) } catch (e: Exception) {}
    }
}
