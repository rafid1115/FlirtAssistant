package com.flirtassistant

import android.content.Context
import android.os.Bundle
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.flirtassistant.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences("flirt_prefs", Context.MODE_PRIVATE)

        // Load saved values
        binding.etApiKey.setText(prefs.getString("api_key", ""))
        val flirtLevel = prefs.getInt("flirt_level", 5)
        binding.seekBarFlirt.progress = flirtLevel
        binding.tvFlirtLevel.text = getFlirtLevelDesc(flirtLevel)
        binding.switchAllApps.isChecked = prefs.getBoolean("monitor_all_apps", false)

        // Seek bar listener
        binding.seekBarFlirt.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.tvFlirtLevel.text = getFlirtLevelDesc(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Save button
        binding.btnSave.setOnClickListener {
            prefs.edit()
                .putString("api_key", binding.etApiKey.text.toString().trim())
                .putInt("flirt_level", binding.seekBarFlirt.progress)
                .putBoolean("monitor_all_apps", binding.switchAllApps.isChecked)
                .apply()

            android.widget.Toast.makeText(this, "✅ הגדרות נשמרו!", android.widget.Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun getFlirtLevelDesc(level: Int): String = when {
        level <= 2 -> "😊 עדין מאוד ($level/10)"
        level <= 4 -> "🙂 חברותי ($level/10)"
        level <= 6 -> "😏 פלרטטני ($level/10)"
        level <= 8 -> "😍 רומנטי ($level/10)"
        else -> "🔥 נועז ($level/10)"
    }
}
